#include "network.h"
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <AsyncElegantOTA.h>
#include <Firebase.h>
#include <addons/RTDBHelper.h>
#include <addons/TokenHelper.h>
#include "monitor.h"
#include <NTPClient.h>
#include <WiFiUdp.h>

#define ssid "Virus"
#define pass "radioactivearea"
String ip;

AsyncWebServer server(80);
monitor Disp;

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "asia.pool.ntp.org", 25200);

bool clear = false;
String weekDays[7]={"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

void ota::init()
{
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);
    while (WiFi.status() != WL_CONNECTED)
    {
        Disp.loading();
        Serial.print(".");
        delay(500);
    }
    ip = WiFi.localIP().toString();

    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", "Hi! I am ESP32.");
    });

    AsyncElegantOTA.begin(&server);
    server.begin();
    Serial.println(WiFi.localIP());

    timeClient.begin();
}

void ota::setting(bool state)
{
    if (state)
    {
        Disp.setting(ip, ssid, pass);
        clear = true;
    }

    else
    {
        if (clear)
        {
            Disp.clear();
            clear = false;
        }
        
    }
}

void ota::time()
{
    timeClient.update();
    if (!timeClient.update())
    {
        timeClient.forceUpdate();
    }

    String date;
    unsigned long epochTime = timeClient.getEpochTime();
    String weekDay = weekDays[timeClient.getDay()];

    struct tm *ptm = gmtime ((time_t *)&epochTime);
    int monthDay = ptm->tm_mday;
    int currentMonth = ptm->tm_mon+1;
    int currentYear = ptm->tm_year+1900;

    String currentDate = weekDay + "," + String(monthDay) + "/" + String(currentMonth) + "/" + String(currentYear);

    date = "         " + timeClient.getFormattedTime() + "\n     " + currentDate;

    // date = timeClient.getDay();
    Disp.recUper();
    Disp.print(date, 3, 5, 0x87e1, 1);
    
}

#define API_KEY "AIzaSyDZi6Rdzb1qGdS1N4AJhgeZAM_OgYxrTuY"
#define FIREBASE_PROJECT_ID "biogas-monitoring-4d3e1"
#define USER_EMAIL "esp@gmail.com"
#define USER_PASS "12345678"
#define DATABASE_URL "https://biogas-monitoring-4d3e1-default-rtdb.firebaseio.com/"

FirebaseData db;
FirebaseAuth auth;
FirebaseConfig config;
FirebaseJson json;

String UID;

void firebase_local::init()
{
    config.api_key = API_KEY;
    auth.user.email = USER_EMAIL;
    auth.user.password = USER_PASS;
    config.database_url = DATABASE_URL;
    Firebase.reconnectWiFi(true);
    db.setResponseSize(4096);
    config.token_status_callback = tokenStatusCallback;
    config.max_token_generation_retry = 5;
    Firebase.begin(&config, &auth);
    
    while (auth.token.uid == "")
    {
        // Disp.loading();
        // Serial.print(".");
        // delay(1000);
    }

    UID = auth.token.uid.c_str();

    this -> getValue();
    Disp.clear();
}

void firebase_local::getValue()
{
    String CO2_path = "/data/CO2";
    String CH4_path = "/data/CH4";
    String CO2_maxVal_path = "/data/CO2/maxValue";
    String CO2_minVal_path = "/data/CO2/minValue";
    String CH4_maxVal_path = "/data/CH4/maxValue";
    String CH4_minVal_path = "/data/CH4/minValue";
    // int count = 0;
    if (Firebase.RTDB.pathExisted(&db,CO2_path))
    {
        if (Firebase.RTDB.getInt(&db, CO2_maxVal_path))
        {
            if (db.dataType() == "int")
            {
                this -> CO2_maxValue = db.intData();
                Serial.print("CO2 Max = ");
                Serial.print(db.intData());
            }
        }
    }

    if (Firebase.RTDB.pathExisted(&db,CO2_path))
    {
        if (Firebase.RTDB.getInt(&db, CO2_minVal_path))
        {
            if (db.dataType() == "int")
            {
                this -> CO2_minValue = db.intData();
                Serial.print(" || CO2 Min = ");
                Serial.print(db.intData());
            }
        }
    }

    if (Firebase.RTDB.pathExisted(&db,CH4_path))
    {
        if (Firebase.RTDB.getInt(&db, CH4_maxVal_path))
        {
            if (db.dataType() == "int")
            {
                this -> CH4_maxValue = db.intData();
                Serial.print(" || CH4 Max = ");
                Serial.print(db.intData());
            }
        }
    }

    if (Firebase.RTDB.pathExisted(&db,CH4_path))
    {
        if (Firebase.RTDB.getInt(&db, CH4_minVal_path))
        {
            if (db.dataType() == "int")
            {
                this -> CH4_minValue = db.intData();
                Serial.print(" || CH4 Min = ");
                Serial.print(db.intData());
            }
        }
    }

    Serial.println();
    
}

void firebase_local::sendData(int CH4, int CO2)
{
    Firebase.RTDB.setInt(&db, "/data/CH4/value", CH4);
    Firebase.RTDB.setInt(&db, "/data/CO2/value", CO2);
}
