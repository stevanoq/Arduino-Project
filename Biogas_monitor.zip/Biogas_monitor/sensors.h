class MQ4_Sens
{
private:

public:
    int methane;
    void init();
    void read();
};


class MQ135_Sens
{
private:
    /* data */
public:
    int co2;
    void init();
    void read();
};
