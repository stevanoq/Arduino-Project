#include "sensors.h"
#include <MQUnifiedsensor.h>
#include "monitor.h"

#define Board ("ESP-32")
#define Voltage_Resolution (3.3)
#define ADC_Bit_Resolution (12)

#define RatioMQ4CleanAir (4.4)
#define mq4_pin (34)
#define mq4_type ("MQ-4")

#define RatioMQ135CleanAir (3.6)
#define mq135_pin (35)
#define mq135_type ("MQ-135")

MQUnifiedsensor MQ4(Board, Voltage_Resolution, ADC_Bit_Resolution, mq4_pin, mq4_type);
MQUnifiedsensor MQ135(Board, Voltage_Resolution, ADC_Bit_Resolution, mq135_pin, mq135_type);

monitor DIsp;
void MQ4_Sens::init()
{
    pinMode(mq4_pin, INPUT);
    MQ4.setRegressionMethod(1);
    MQ4.setA(1012.7);
    MQ4.setB(-2.786);
    MQ4.init();

    Serial.print("Calibrating MQ4 please wait");
    float calcR0 = 0;
    for(int i = 1; i <= 10; i++){
        MQ4.update();
        calcR0 += MQ4.calibrate(RatioMQ4CleanAir);
        Serial.print(".");
    }

    MQ4.setR0(calcR0/10);
    Serial.print("MQ4 calibrate done");

    if (isinf(calcR0))
    {
        DIsp.calibrating_fail("MQ4");
        Serial.println("Warning: Conection issue, R0 is infinite (Open circuit detected) please check your wiring and supply");
        while(1);
    }

    if (calcR0 == 0){
        DIsp.calibrating_fail("MQ4");
        Serial.println("Warning: Conection issue found, R0 is zero (Analog pin shorts to ground) please check your wiring and supply"); 
        while(1);
    }
    
    MQ4.serialDebug(true);
}

void MQ4_Sens::read()
{
    MQ4.update();
    MQ4.readSensor();
    this->methane = MQ4.readSensor();
    // MQ4.serialDebug();
}

void MQ135_Sens::init()
{
    pinMode(mq135_pin, INPUT);
    MQ135.setRegressionMethod(1);
    MQ135.setA(605.18);
    MQ135.setB(-3.937);
    MQ135.init();

    Serial.println("calibrating MQ135");

    float calcR0 = 0;

    for(int i = 1; i <= 10; i++){
        MQ135.update();
        calcR0 += MQ135.calibrate(RatioMQ135CleanAir);
        Serial.print(".");
    }

    MQ135.setR0(calcR0/10);
    Serial.print("Calibrating MQ135 done");

    if(isinf(calcR0)) {
        DIsp.calibrating_fail("MQ135");
        Serial.println("Warning: Conection issue, R0 is infinite (Open circuit detected) please check your wiring and supply"); 
        while(1);
    }
    if(calcR0 == 0){
        DIsp.calibrating_fail("MQ135");
        Serial.println("Warning: Conection issue found, R0 is zero (Analog pin shorts to ground) please check your wiring and supply"); 
        while(1);
    }

    MQ135.serialDebug(true);

}

void MQ135_Sens::read()
{
    MQ135.update();
    MQ135.readSensor();
    this->co2 = MQ135.readSensor();
}
