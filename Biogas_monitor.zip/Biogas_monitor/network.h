#include <WString.h>

class ota
{
private:
    
public:
    void init();
    void setting(bool state = false);
    void time();
};

class firebase_local
{
private:
    

public:
    int CO2_maxValue;
    int CO2_minValue;
    int CH4_maxValue;
    int CH4_minValue;
    void init();
    void getValue();
    void sendData(int CH4, int CO2);
};
