#include <Arduino.h>
#include <WString.h>

class monitor
{
private:
    unsigned int rainbow(byte value);
    float sineWave(int phase);
    int center_x = 128 / 2; 
    int center_y = 160 / 2; 
public:
    byte RED2RED = 0;
    byte GREEN2GREEN = 1;
    byte BLUE2BLUE = 2;
    byte BLUE2RED = 3;
    byte GREEN2RED = 4;
    byte RED2GREEN = 5;
    void init();
    void getData();
    void clear();
    void loading();
    void calibrating_fail(String sensor);
    void setting(String IP, char *ssid, char *password);
    void print(String data, int x,int y, int collor, int font_size);
    void recUper();
    void drawPerairanLogo();
    void drawBiogasLogo();
    void drawKemendikbudLogo();
    int ringMeter(int value, int vmin, int vmax, int x, int y, int r, char *units, byte scheme, char *lable = "-", int text_size = 1);
};
