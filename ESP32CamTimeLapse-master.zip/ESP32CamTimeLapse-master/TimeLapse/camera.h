#pragma once
#include "esp_camera.h"

bool initCamera();
