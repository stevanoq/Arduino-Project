#!/bin/bash
cd ${HOME}/Arduino/libraries
git clone https://github.com/me-no-dev/ESPAsyncWebServer.git ESPAsyncWebServer
git clone https://github.com/me-no-dev/ESPAsyncTCP.git ESPAsyncTCP
git clone https://github.com/me-no-dev/AsyncTCP.git AsyncTCP
