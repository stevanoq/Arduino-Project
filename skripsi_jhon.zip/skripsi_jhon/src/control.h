<<<<<<< HEAD
#include <WString.h>

class control
{
private:
    
public:
    void openUpDoor(bool state);
    void openDownDoor(bool state);
    void ledDown(bool state);
    void ledUp(bool state);
    void motor(bool state);
};

=======
#include <WString.h>

class control
{
private:
    
public:
    void openUpDoor(bool state);
    void openDownDoor(bool state);
    void ledDown(bool state);
    void ledUp(bool state);
    void motor(bool state);
};

>>>>>>> 9f4c145668b6fb6c7976d9e7904c2a03d2dd6554
