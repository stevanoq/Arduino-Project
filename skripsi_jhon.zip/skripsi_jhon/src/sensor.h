<<<<<<< HEAD
#include <WString.h>

class sensor
{
private:
    /* data */
public:
    void init();
    bool irVal(void);
    bool switchUpVal(void);
    bool switchDownVal(void);
    
};

=======
#include <WString.h>

class sensor
{
private:
    /* data */
public:
    void init();
    bool irVal(void);
    bool switchUpVal(void);
    bool switchDownVal(void);
    
};

>>>>>>> 9f4c145668b6fb6c7976d9e7904c2a03d2dd6554
