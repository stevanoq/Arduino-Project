<<<<<<< HEAD
class ota
{

public:
    void init();
    void check();
};

=======
class ota
{

public:
    void init();
    void check();
};

>>>>>>> 9f4c145668b6fb6c7976d9e7904c2a03d2dd6554
